package jns.util;


public class Status
{

    public final static int UP = 1;
    public final static int DOWN = 2;

}
